# Release Notes

This topic contains release notes for Tanzu Application Platform beta.

**Releases**

## <a id='0-2-0'></a> v0.2.0 Beta-2

**Release Date**: October XX, 2021

### Breaking Changes

Breaking changes in this release:

- STATE any breaking changes here, or delete this section.

### New Features

New features in this release:

- **Short description of NEW feature:**
  More detailed information about NEW feature.

### Bug Fixes

This release has the following bug fixes:

- **Bold run-in heading for fIX:** Description of FIX.

### Known Issues

This release has the following issues:

- **Short description of KNOWN issue:**
  More details about the KNOWN issue.



## <a id='0-2-0'></a> v0.1.0 Beta

**Release Date**: September 1, 2021

Initial release.

