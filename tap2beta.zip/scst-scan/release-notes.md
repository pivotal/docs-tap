# Release Notes

This topic contains release notes for Supply Chain Security Tools for Tanzu – Scan

## Releases

### v1.0.0-beta

**Release Date:** October 07, 2021

## Additional Considerations

* Our scanner templates require internet access to download the vulnerability database at scan time.