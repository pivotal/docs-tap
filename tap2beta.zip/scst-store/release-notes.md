# Release Notes

This topic contains release notes for Supply Chain Security Tools - Store.

**Releases**

## <a id='0-2-0'></a> v0.1.0 

**Release Date**: October 07, 2021

### Known Issues

This release has the following issues:

- **Air Gap Not Supported:**
  Supply Chain Security Tools - Store does not support air gapping. 