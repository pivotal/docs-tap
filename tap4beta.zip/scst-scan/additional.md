# Additional Resources

* [Configure Code Repositories and Image Artifacts to be Scanned](scan-crs.md)
* [Code and Image Compliance Policy Enforcement Using Open Policy Agent (OPA)](policies.md)
* [How to Create a ScanTemplate](create-scan-template.md)
* [Viewing and Understanding Scan Status Conditions](results.md)
