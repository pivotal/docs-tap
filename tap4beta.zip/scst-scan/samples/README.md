# More Scan Samples
This section provides samples on multiple use cases that can be copied in your cluster for testing purposes.  

1. [Running a Sample Public Source Scan of a Blob](blob.md)
2. [Running a Sample Private Image Scan](private-image.md)
3. [Running a Sample Private Source Scan](private-source.md)
