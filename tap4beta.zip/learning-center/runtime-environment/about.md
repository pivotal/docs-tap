# Learning Center Runtime Environment

## Overview
This section includes information on the Custom Resource Definitions (CRDs) that are
part of Learning Center.

- [Custom Resource Overview](custom-resources.md)
- [Workshop Resource](workshop-definition.md)
- [WorkshopEnvironment Resource](workshop-environment.md)
- [WorkshopRequest Resource](workshop-request.md)
- [WorkshopSession Resource](workshop-session.md)
- [TrainingPortal Resource](training-portal.md)
- [SystemProfile  Resource](system-profile.md)
