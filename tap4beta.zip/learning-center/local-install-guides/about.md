# Learning Center Local Install Guides

## Overview
These guides are to help you install on your local environment

- [Installing on Kind](deploying-to-kind.md)
- [Installing on Minikube](deploying-to-minikube.md)