## Tanzu Application Platform GUI Plugins

### Overview
The Tanzu Application Platform GUI has many pre-integrated plugins. 
You do not need to configure the plugins. To use the plugin,
you need to install the Tanzu Application Platform component.

Tanzu Application Platform includes the following GUI Plugins:

- [Workload Visibility](workload-visibility.md)
- [Application Live View](app-live-view.md)
