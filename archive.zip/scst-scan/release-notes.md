# Release Notes

This topic contains release notes for Supply Chain Security Tools for VMware Tanzu – Scan

**Releases**

v1.0.0-beta.0

**Release Date**: October XX, 2021

Initial release.

